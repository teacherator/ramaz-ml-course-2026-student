"""HW00 — Python Bootcamp: Implementation

Complete the functions below. Each function has a docstring describing
what it should do, along with examples. Run `uv run pytest` to check
your work, and `uv run python score.py` to see your current grade.
"""

from __future__ import annotations

from typing import Callable
import pytest

# ── Part 1: Lists ─────────────────────────────────────────────────────────────


def flatten(nested: list[list]) -> list:
    """Return a single flat list from a list of lists.

    Examples:
        >>> flatten([[1, 2], [3, 4], [5]])
        [1, 2, 3, 4, 5]
        >>> flatten([[], [1]])
        [1]
        >>> flatten([])
        []
    """
    flattened = []
    for i in nested:
        for j in i:
            flattened.append(j)

    return flattened


def most_frequent(items: list) -> object:
    """Return the element that appears most often in items.

    If there is a tie, returning any one of the tied elements is fine.
    Raise ValueError if items is empty.

    Examples:
        >>> most_frequent([1, 2, 2, 3])
        2
        >>> most_frequent(['a', 'b', 'a', 'c', 'a'])
        'a'
    """
    #get rid of NotImplementedError and implement the function here
    #raise NotImplementedError("Implement most_frequent()")
   
    if items==[]:
        raise ValueError()
    mostItem = {}
    mostCount=0
    for i in items:
        thisCount=items.count(i)
        if thisCount >= mostCount:
            mostCount = thisCount
            mostItem = i
    
    return mostItem
    



def running_average(numbers: list[float]) -> list[float]:
    """Return the cumulative average at each position.

    The i-th element of the result is the mean of numbers[0], ..., numbers[i].

    Examples:
        >>> running_average([10.0, 20.0, 30.0])
        [10.0, 15.0, 20.0]
        >>> running_average([4.0])
        [4.0]
        >>> running_average([])
        []
    """
    #raise NotImplementedError("Implement running_average()")
    result=[]
    for i,v  in enumerate(numbers):
        print(i, numbers[:i+1])
        result.append(sum(numbers[:i+1])/(i+1))
    
    return result

#print("running average", running_average([10.0, 20.0, 30.0]))

def chunk(items: list, size: int) -> list[list]:
    """Split items into sublists of length size.

    The last sublist may be shorter if len(items) is not divisible by size.

    Examples:
        >>> chunk([1, 2, 3, 4, 5], 2)
        [[1, 2], [3, 4], [5]]
        >>> chunk([1, 2, 3], 3)
        [[1, 2, 3]]
        >>> chunk([], 4)
        []
    """
    #raise NotImplementedError("Implement chunk()")

    
    fullchunks = len(items)//size
    partchunk = len(items)%size
    print(fullchunks, partchunk)

    chunked = [[0] * size for _ in range(fullchunks)]
    if partchunk > 0: chunked.append([0]*partchunk)
    print(chunked)
    count =0
    for i,chunk in enumerate(chunked):
        for ii,v in enumerate(chunk):
            chunked[i][ii]=items[count]
            count+=1
     

    print(chunked)

    #




    return chunked
#chunk([1, 2, 3, 4, 5], 2)
#chunk([1, 2, 3], 3)

def rotate(items: list, k: int) -> list:
    """Rotate items left by k positions.

    A negative k rotates right. If items is empty, return [].
    k larger than len(items) wraps around correctly.

    Examples:
        >>> rotate([1, 2, 3, 4, 5], 2)
        [3, 4, 5, 1, 2]
        >>> rotate([1, 2, 3], -1)
        [3, 1, 2]
        >>> rotate([1, 2, 3], 4)
        [2, 3, 1]
    """
    #raise NotImplementedError("Implement rotate()")
    itemlen=len(items)
    if(k>=0):
        if (k>itemlen):
            items.extend(items[:k])
            items.extend(items[:k-itemlen])
            print("extended",items)
            del items[:k]
            print("rotated",items)

        else:    
            items.extend(items[:k])
            print("extended",items)
            del items[:k]
            print("rotated",items)
    else:
        items[:0]=items[k:]
        print("extended",items)
        del items[k:]
        print("rotated",items)

    return items

#rotate([1, 2, 3], 4)

def run_length_encode(items: list) -> list[tuple]:
    """Compress consecutive identical elements into (count, value) tuples.

    Examples:
        >>> run_length_encode(['a', 'a', 'b', 'b', 'b', 'a'])
        [(2, 'a'), (3, 'b'), (1, 'a')]
        >>> run_length_encode([1, 2, 3])
        [(1, 1), (1, 2), (1, 3)]
        >>> run_length_encode([])
        []
    """
    #raise NotImplementedError("Implement run_length_encode()")
    if(items==[]):return []
    run_len=[]
    count=1
    prev=items[0]
    for i,v in enumerate(items):
        if(i==0 and len(items)==1):
            return [(1,v)]
        if(i==0):continue
        if(v==prev):
            count+=1
            if(i==len(items)-1):
                run_len.append((count,prev))    
        else:
            run_len.append((count,prev))
            count=1
            if(i==len(items)-1):
                run_len.append((count,v)) 
        prev=v
        
    print("run_len",run_len)
    return run_len

#run_length_encode(['a', 'a', 'b', 'b', 'b', 'a'])
#run_length_encode('x')

def sliding_window(items: list, size: int) -> list[list]:
    """Return all consecutive windows of length size.

    Each window overlaps with the previous one by size-1 elements.
    If len(items) < size, return [].

    Examples:
        >>> sliding_window([1, 2, 3, 4, 5], 3)
        [[1, 2, 3], [2, 3, 4], [3, 4, 5]]
        >>> sliding_window([1, 2, 3], 2)
        [[1, 2], [2, 3]]
        >>> sliding_window([1, 2], 3)
        []
        >>> sliding_window([], 2)
        []
    """
    #raise NotImplementedError("Implement sliding_window()")
    print("items",items)
    if (len(items) < size or len(items)==0): return []
    windows = [[0] * size for _ in range(len(items[size:])+1)]
    print("0win",windows)
    for i,v in enumerate(windows):
        windows[i]=items[i:i+size]
    
    return windows

#print(sliding_window([1, 2, 3], 2))
#print(sliding_window([1, 2, 3, 4, 5], 3))
#print(sliding_window([], 2))
#print(sliding_window([1, 2, 3], 3))
#print(sliding_window(list(range(10)), 4))
#print(sliding_window([1, 2], 3))

# ── Part 2: Dictionaries ──────────────────────────────────────────────────────


def count_occurrences(items: list) -> dict:
    """Return a dict mapping each unique element to its count in items.

    Examples:
        >>> count_occurrences(['a', 'b', 'a', 'c', 'b', 'b'])
        {'a': 2, 'b': 3, 'c': 1}
        >>> count_occurrences([])
        {}
    """
    #raise NotImplementedError("Implement count_occurrences()")
    keys = []
    for i in items:
        if keys.count(i) < 1:
            keys.append(i)
    print(keys)

    count_dic = dict.fromkeys(keys)
    for k,v in count_dic.items():
        count_dic[k]=items.count(k)
    
    return count_dic 
print(count_occurrences(['a', 'b', 'a', 'c', 'b', 'b']))
#"Expected {{'a': 2, 'b': 3, 'c': 1}}

def invert_dict(d: dict) -> dict:
    """Return a new dict with keys and values swapped.

    Examples:
        >>> invert_dict({'a': 1, 'b': 2})
        {1: 'a', 2: 'b'}
    """
    inver = {}
    for k,v in d.items():
        inver.update({v:k})
       
    return inver
#print(invert_dict({'a': 1, 'b': 2}))
    
def group_by(items: list[dict], key: str) -> dict[str, list[dict]]:
    """Group a liqst of dicts by the value at the given key.

    Examples:
        >>> records = [
        ...     {'name': 'Alice', 'dept': 'Eng'},
        ...     {'name': 'Bob', 'dept': 'HR'},
        ...     {'name': 'Carol', 'dept': 'Eng'},
        ... ]
        >>> result = group_by(records, 'dept')
        {
            'Eng':[
                {'name': 'Alice', 'dept': 'Eng'},
                {'name': 'Carol', 'dept': 'Eng'}
                ],
             'HR':[
                {'name': 'Bob', 'dept': 'HR'}
             ]
        }
        >>> len(result['Eng'])
        2
        >>> len(result['HR'])
        1
    """
    keys = []
    for i in items:
        if keys.count(i[key]) < 1:
            keys.append(i[key])
    print(keys)
    grouped={}
    for k in keys:
        grouped[k]=[]
        for i in items:
            if i[key]==k: grouped[k].append(i)


    
    return grouped


records = [
        {'name': 'Alice', 'dept': 'Eng'},
        {'name': 'Bob', 'dept': 'HR'},
        {'name': 'Carol', 'dept': 'Eng'},
        ]
result = group_by(records, 'dept')
print(result)

def deep_get(d: dict, path: str, default: object = None) -> object:
    """Retrieve a value from a nested dict using a dot-separated key path.

    Return default if any key along the path is missing.

    Examples:
        >>> deep_get({'a': {'b': {'c': 42}}}, 'a.b.c')
        42
        >>> deep_get({'a': 1}, 'a.b', default=-1)
        -1
        >>> deep_get({'x': 10}, 'y')  # returns None (default)
    """
    val={}
    #turn path into a list
    path_list = path.split('.')
    try:
        iter(d)
    except TypeError:
        return default
   
    
    if(path_list[0] in d):
        if (len(path_list)==1): 
            val = d[path_list[0]]
        else:
            val = deep_get(d[path_list[0]], ".".join(path_list[1:]),default)
    else:
        return default

    return val

#print(deep_get({'a': {'b': {'c': 42}}}, 'a.b.c'))
#print(deep_get({"a": 1}, "a.b", default=-1))


def two_sum(nums: list[int], target: int) -> tuple[int, int] | None:
    """Return indices (i, j) where nums[i] + nums[j] == target, with i < j.

    Return None if no such pair exists.

    Hint: There is an elegant O(n) solution using a dict. As you scan through
    nums, ask: "have I already seen the number I need to pair with this one?"

    Examples:
        >>> two_sum([2, 7, 11, 15], 9)
        (0, 1)
        >>> two_sum([3, 2, 4], 6)
        (1, 2)
        >>> two_sum([1, 2, 3], 100)
        None
    """
    sum_dict={}
    
    for i1,v1 in enumerate(nums):
        sum_dict[i1]=v1
        if i1 > 0:
            for i in range(0,i1):
                if (sum_dict[i]+v1==target):
                    print("in dict if" )
                    return(i,i1)
        #for i2,v2 in enumerate(nums):
           # if(v2+v1==target):
               # if(i1<i2):
                   # return (i1,i2)

    

    return None
#print(two_sum([2, 7, 11, 15], 9))
#print(two_sum([3, 2, 4], 6)) #(1, 2)

# ── Part 3: Sets ──────────────────────────────────────────────────────────────


def find_duplicates(items: list) -> set:
    """Return the set of elements that appear more than once in items.

    Examples:
        >>> find_duplicates([1, 2, 2, 3, 3, 3, 4])
        {2, 3}
        >>> find_duplicates([1, 2, 3])
        set()
        >>> find_duplicates([])
        set()
    """
    dupes=set()
    for i in items:
        count = 0
        for ii in items:
            if (i == ii): 
                count+=1
                if (count >1):dupes.add(i)
                continue

    return  dupes

#print(find_duplicates([1, 2, 2, 3, 3, 3, 4]))

def jaccard_similarity(a: set, b: set) -> float:
    """Return |A intersection B| / |A union B|.

    Return 0.0 if both sets are empty.

    Examples:
        >>> jaccard_similarity({1, 2, 3}, {2, 3, 4}) 2+3 / 1+2+3+4
        0.5
        >>> jaccard_similarity({1, 2}, {3, 4})
        0.0
        >>> jaccard_similarity(set(), set())
        0.0
    """
    sim=0.0
    intersect = a.intersection(b)
    union = a.union(b)
    if(len(union)>0):
        sim=len(intersect)/len(union)
    return sim
#print(jaccard_similarity({1, 2}, {1, 2, 3, 4}))   


# ── Part 4: Higher-order functions ────────────────────────────────────────────


def apply_twice(f: Callable, x: object) -> object:
    """Apply f to x, then apply f to the result: f(f(x)).

    Examples:
        >>> apply_twice(lambda n: n * 2, 3)
        12
        >>> apply_twice(str.upper, 'hello')
        'HELLO'
    """

    return f(f(x))

#print(apply_twice(str.upper, 'hello'))


def make_multiplier(n: float) -> Callable[[float], float]:
    """Return a function that multiplies its argument by n.

    Each call to make_multiplier returns an independent function.

    Examples:
        >>> double = make_multiplier(2)
        >>> double(5)
        10.0
        >>> triple = make_multiplier(3)
        >>> triple(4)
        12.0
    """
    return lambda x: x * n
#double = make_multiplier(2)
#print(double(5))


def pipeline(*funcs: Callable) -> Callable:
    """Return a single function that applies each func in sequence (left to right).

    pipeline(f, g, h)(x) is equivalent to h(g(f(x))).
    If no functions are provided, the returned function is the identity: f(x) == x.

    Examples:
        >>> add1 = lambda x: x + 1
        >>> double = lambda x: x * 2
        >>> pipeline(add1, double)(3)
        8
        >>> pipeline()(42)
        42
    """
    
    def composed(x):
        result = x
        for f in funcs:
            result=f(result)
        return result
    return composed

#add1 = lambda x: x + 1
#double = lambda x: x * 2
#print(pipeline(add1, double)(3))


def memoize(f: Callable) -> Callable:
    """Return a version of f that caches results by argument.

    Calling the memoized function with the same argument a second time
    must return the cached result WITHOUT calling f again.

    Use a closure over a dict to store previously computed results.

    Examples:
        >>> call_count = 0
        >>> def tracked(x):
        ...     global call_count
        ...     call_count += 1
        ...     return x ** 2
        >>> cached = memoize(tracked)
        >>> cached(4)
        16
        >>> cached(4)   # should not increment call_count
        16
    """
    cache = {} #mutable dict is globallike in scope
    def getterSetter(arg):
        
        if arg not in cache:
            cache[arg]=f(arg) #adds to cache
        return cache[arg]
    
    return getterSetter



"""
call_count = 0
def tracked(x):
    global call_count
    call_count += 1
    return x ** 2
cached = memoize(tracked)
print(cached(3))
print("call count ",call_count)
print(cached(3))   # should not increment call_count
print("call count ",call_count)

def tracked3(x):
    global call_count
    call_count += 1
    return x ** 3
cached = memoize(tracked3)
print(cached(3))


"""


# ── Part 5: Classes ───────────────────────────────────────────────────────────


class Student:
    """A student with a name and a list of grades (0-100).

    Supports comparison via average grade, enabling natural sorting.
    """

    def __init__(self, name: str, grades: list[float]) -> None:
        self.name = name
        self.grades = grades

    def average(self) -> float:
        """Return the mean of all grades. Returns 0.0 if grades is empty."""
        if (self.grades == []):return 0.0
        else: return sum(self.grades)/len(self.grades)

    def highest(self) -> float:
        """Return the highest grade. Returns 0.0 if grades is empty."""
        
        if (self.grades == []):return 0.0
        else: return max(self.grades)

    def letter_grade(self) -> str:
        """Return the letter grade for this student's average.

        Boundaries: A >= 90, B >= 80, C >= 70, D >= 60, F otherwise.
        """
        if self.average() >= 90: return "A"
        elif self.average() >= 80: return "B"
        elif self.average() >= 70: return "C"
        elif self.average() >= 60: return "D"
        else: return "F"

    def __repr__(self) -> str:
        """Return a string like: Student('Alice', avg=88.5)"""
        return str(self.name)+", "+str(self.average())

    def __lt__(self, other: "Student") -> bool:
        """Compare students by average grade (enables sorted() and min/max)."""
        if not isinstance(other, Student):
            return NotImplemented  # Restricts comparison to only other Students
        return self.average() < other.average()
#s = Student("Alice", [80.0, 90.0])
#print(repr(s))

class Gradebook:
    """Manages a collection of students, keyed by name."""

    def __init__(self) -> None:
        self.students: dict[str, Student] = {}

    def add_student(self, student: Student) -> None:
        """Add a student to the gradebook.

        Raises ValueError if a student with the same name already exists.
        """
        if student.name in self.students: raise ValueError
        else:
            self.students[student.name]=student

    def top_students(self, n: int) -> list[Student]:
        """Return the n students with the highest averages, in descending order."""
        s=self.students
        highest = sorted(self.students.items(), key= lambda item: sum(item[1].grades)/len(item[1].grades),reverse=True)
        hi =[]
        for i in highest:
            hi.append((i[1]))
        return hi[:n]
        


    def class_average(self) -> float:
        """Return the mean of all student averages. Returns 0.0 if empty."""
        if self.students=={}: return 0.0
        avg=[]
        for i in self.students.values():
            avg.append(sum(i.grades)/len(i.grades))
        return sum(avg)/len(avg)

#gb = Gradebook()
#print(gb.class_average())